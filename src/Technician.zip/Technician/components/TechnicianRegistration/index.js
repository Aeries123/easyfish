const TechnicianRegistration = () => {
    return (
      <div>
        <h1>TechnicianRegistration</h1>
      </div>
    );
  };
  
  export default TechnicianRegistration;
  