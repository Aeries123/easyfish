import { useState } from "react";
import "./customersignup.css"

const CustomerSignup = () => {
  const [customerDetails, setCustomerDetails] = useState({
    customerName: "",
    customerDoB: "",
    customerGender: "",
    customerStreet: "",
    customerCity: "",
    customerState: "",
    customerCountry: "",
    customerPostalCode: "",
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setCustomerDetails({ ...customerDetails, [name]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Customer Details:", customerDetails);
    alert("Customer signed up successfully!");
  };

  return (
    <div className="sign-up-container">
    <form onSubmit={handleSubmit} >
      <h2>Customer Signup</h2>
      <div>
        <label>Full Name:</label>
        <input
          type="text"
          name="customerName"
          value={customerDetails.customerName}
          onChange={handleChange}
          required
        />
      </div>
      <div>
        <label>Date of Birth:</label>
        <input
          type="date"
          name="customerDoB"
          value={customerDetails.customerDoB}
          onChange={handleChange}
          required
        />
      </div>
      <div>
        <label>Gender:</label>
        <select
          name="customerGender"
          value={customerDetails.customerGender}
          onChange={handleChange}
          required
        >
          <option value="">Select</option>
          <option value="Male">Male</option>
          <option value="Female">Female</option>
          <option value="Other">Other</option>
        </select>
      </div>
      <div>
        <label>Street:</label>
        <input
          type="text"
          name="customerStreet"
          value={customerDetails.customerStreet}
          onChange={handleChange}
          required
        />
      </div>
      <div>
        <label>City:</label>
        <input
          type="text"
          name="customerCity"
          value={customerDetails.customerCity}
          onChange={handleChange}
          required
        />
      </div>
      <div>
        <label>State:</label>
        <input
          type="text"
          name="customerState"
          value={customerDetails.customerState}
          onChange={handleChange}
          required
        />
      </div>
      <div>
        <label>Country:</label>
        <input
          type="text"
          name="customerCountry"
          value={customerDetails.customerCountry}
          onChange={handleChange}
          required
        />
      </div>
      <div>
        <label>Postal Code:</label>
        <input
          type="text"
          name="customerPostalCode"
          value={customerDetails.customerPostalCode}
          onChange={handleChange}
          required
        />
      </div>
      <button type="submit">Signup</button>
    </form>
    </div>
  );
};

export default CustomerSignup;
