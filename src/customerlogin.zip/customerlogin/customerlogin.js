import { useState } from "react";
import "./customerlogin.css"; // Import the CSS file

const CustomerLogin = () => {
  const [loginDetails, setLoginDetails] = useState({
    phoneNumber: "",
    mobileOtp: "",
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setLoginDetails({ ...loginDetails, [name]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Login Details Submitted:", loginDetails);
    alert("Login successful!");
  };

  return (
    <form className="login-form" onSubmit={handleSubmit}>
      <h2 className="form-title">Customer Login</h2>
      <div className="form-group">
        <label htmlFor="phoneNumber">Phone Number:</label>
        <input
          type="tel"
          id="phoneNumber"
          name="phoneNumber"
          value={loginDetails.phoneNumber}
          onChange={handleChange}
          required
        />
      </div>
      <div className="form-group">
        <label htmlFor="mobileOtp">OTP:</label>
        <input
          type="text"
          id="mobileOtp"
          name="mobileOtp"
          value={loginDetails.mobileOtp}
          onChange={handleChange}
          required
        />
      </div>
      <button type="submit" className="login-button">
        Login
      </button>
    </form>
  );
};

export default CustomerLogin;
