const TechnicianSidebar = () => {
    return (
      <div>
        <h1>TechnicianSidebar</h1>
      </div>
    );
  };
  
  export default TechnicianSidebar;
  