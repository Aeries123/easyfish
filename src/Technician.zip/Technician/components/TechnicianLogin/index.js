const TechnicianLogin = () => {
    return (
      <div>
        <h1>TechnicianLogin</h1>
      </div>
    );
  };
  
  export default TechnicianLogin;
  